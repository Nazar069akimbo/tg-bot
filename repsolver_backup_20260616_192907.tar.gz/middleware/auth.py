from aiogram import BaseMiddleware
from typing import Callable, Dict, Any, Awaitable
from aiogram.types import TelegramObject, Message, CallbackQuery
from database.db import is_user_blocked

class AuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        # Проверяем сообщения
        if isinstance(event, Message) and event.from_user:
            if is_user_blocked(event.from_user.id):
                await event.answer("⛔ Вы заблокированы. Обратитесь к администратору.")
                return
        
        # Проверяем callback'и
        elif isinstance(event, CallbackQuery) and event.from_user:
            if is_user_blocked(event.from_user.id):
                await event.answer("⛔ Вы заблокированы", show_alert=True)
                return
        
        return await handler(event, data)
