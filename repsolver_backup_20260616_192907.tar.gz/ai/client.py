import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(
    api_key=os.getenv("BOTHUB_API_KEY"),
    base_url="https://openai.bothub.chat/v1"
)

def solve_problem(question, mode="gdz"):
    if mode == "chat":
        prompt = """Ты дружелюбный помощник. Отвечай кратко и понятно.
        Пиши обычным текстом, без LaTeX, без формул вроде \sqrt{}, \frac{}, \times и т.д.
        Используй обычные символы: корень пиши как "√", дробь как "число/число", умножение как "*" или "×"."""
    else:
        prompt = """Ты репетитор по математике. Решай задачи и объясняй понятным русским языком.

        ВАЖНО: 
        - НЕ используй LaTeX
        - НЕ пиши \sqrt{}, \frac{}, \times, \div и т.д.
        - Пиши всё обычным текстом
        - Корень пиши как "√(число)"
        - Дробь пиши как "число/число"
        - Степень пиши как "число^степень"
        - Отвечай кратко и по делу
        - Не пиши слишком длинные объяснения
        - Дай четкий ответ в конце"""
    
    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": question}
            ],
            max_tokens=400,
            temperature=0.3
        )
        return resp.choices[0].message.content
    except Exception as e:
        return f"⚠️ Ошибка: {e}"
