from aiogram import Router, types
from aiogram.filters import Command
from database.db import get_user, can_request, is_premium, get_setting
from keyboards import main_menu

router = Router()

@router.message(Command("stats"))
async def stats_cmd(message: types.Message):
    user = get_user(message.from_user.id)
    if not user:
        await message.answer("Напиши /start")
        return
    
    ok, remaining = can_request(message.from_user.id)
    premium = is_premium(message.from_user.id)
    status = "💎 Premium" if premium else "🔴 Бесплатный"
    mode = "📚 ГДЗ" if user[7] == "gdz" else "💬 Общение"
    
    # Получаем лимит из настроек
    free_limit = int(get_setting('free_limit'))
    
    text = f"📊 **Статистика**\n\n"
    text += f"📝 Решено: {user[5] or 0}\n"
    text += f"🎯 Осталось: {remaining}\n"
    text += f"📊 Лимит: {free_limit} задач/день\n"  # Добавляем лимит
    text += f"💎 Статус: {status}\n"
    text += f"🎯 Режим: {mode}"
    
    await message.answer(text, reply_markup=main_menu())

@router.callback_query(lambda c: c.data == "stats")
async def stats_callback(callback: types.CallbackQuery):
    from keyboards import main_menu
    try:
        user = get_user(callback.from_user.id)
        if not user:
            await callback.message.edit_text("Напиши /start")
            await callback.answer()
            return
        
        ok, remaining = can_request(callback.from_user.id)
        premium = is_premium(callback.from_user.id)
        status = "💎 Premium" if premium else "🔴 Бесплатный"
        mode = "📚 ГДЗ" if user[7] == "gdz" else "💬 Общение"
        
        # Получаем лимит из настроек
        free_limit = int(get_setting('free_limit'))
        
        text = f"📊 **Статистика**\n\n"
        text += f"📝 Решено: {user[5] or 0}\n"
        text += f"🎯 Осталось: {remaining}\n"
        text += f"📊 Лимит: {free_limit} задач/день\n"
        text += f"💎 Статус: {status}\n"
        text += f"🎯 Режим: {mode}"
        
        await callback.message.edit_text(text, reply_markup=main_menu())
        await callback.answer()
    except Exception as e:
        await callback.answer()
