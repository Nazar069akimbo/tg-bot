from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, LabeledPrice
import secrets
from datetime import datetime
from database.db import cursor, conn, add_premium, get_setting
from keyboards import main_menu

router = Router()

@router.message(Command("subscribe"))
async def subscribe_cmd(message: types.Message):
    price_1 = int(get_setting('premium_price_1'))
    price_3 = int(get_setting('premium_price_3'))
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⭐ {price_1} Stars — 1 мес", callback_data="pay_1")],
        [InlineKeyboardButton(text=f"⭐ {price_3} Stars — 3 мес", callback_data="pay_3")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
    ])
    await message.answer(
        "💎 **Premium**\n\n"
        "• Безлимит задач\n"
        f"• {get_setting('premium_symbols')} символов на запрос\n\n"
        f"💰 1 мес — {price_1} Stars\n"
        f"💰 3 мес — {price_3} Stars",
        reply_markup=keyboard
    )

@router.callback_query(lambda c: c.data == "premium")
async def premium_callback(callback: types.CallbackQuery):
    try:
        price_1 = int(get_setting('premium_price_1'))
        price_3 = int(get_setting('premium_price_3'))
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=f"⭐ {price_1} Stars — 1 мес", callback_data="pay_1")],
            [InlineKeyboardButton(text=f"⭐ {price_3} Stars — 3 мес", callback_data="pay_3")],
            [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
        ])
        await callback.message.edit_text(
            "💎 **Premium**\n\n"
            "• Безлимит задач\n"
            f"• {get_setting('premium_symbols')} символов на запрос\n\n"
            f"💰 1 мес — {price_1} Stars\n"
            f"💰 3 мес — {price_3} Stars",
            reply_markup=keyboard
        )
        await callback.answer()
    except Exception as e:
        await callback.answer()

@router.callback_query(lambda c: c.data.startswith("pay_"))
async def pay_callback(callback: types.CallbackQuery):
    try:
        plan = callback.data.replace("pay_", "")
        days_1 = int(get_setting('premium_days_1'))
        days_3 = int(get_setting('premium_days_3'))
        price_1 = int(get_setting('premium_price_1'))
        price_3 = int(get_setting('premium_price_3'))
        
        days = {"1": days_1, "3": days_3}[plan]
        stars = {"1": price_1, "3": price_3}[plan]
        payload = secrets.token_hex(16)
        
        cursor.execute(
            "INSERT INTO payments (user_id, stars_amount, telegram_payload, status, timestamp) VALUES (?, ?, ?, ?, ?)",
            (callback.from_user.id, stars, payload, "pending", datetime.now().isoformat())
        )
        conn.commit()
        
        await callback.bot.send_invoice(
            chat_id=callback.from_user.id,
            title=f"Premium {plan} мес",
            description=f"Безлимит задач на {days} дней",
            payload=payload,
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice(label="Premium", amount=stars)],
            start_parameter="premium_sub"
        )
        await callback.answer()
    except Exception as e:
        await callback.message.answer(f"❌ Ошибка: {e}")
        await callback.answer()

@router.pre_checkout_query()
async def pre_checkout(query: types.PreCheckoutQuery):
    await query.answer(ok=True)

@router.message(lambda m: m.successful_payment is not None)
async def payment_success(message: types.Message):
    payload = message.successful_payment.invoice_payload
    cursor.execute("SELECT stars_amount FROM payments WHERE telegram_payload = ?", (payload,))
    row = cursor.fetchone()
    
    price_1 = int(get_setting('premium_price_1'))
    price_3 = int(get_setting('premium_price_3'))
    days_1 = int(get_setting('premium_days_1'))
    days_3 = int(get_setting('premium_days_3'))
    
    days = 30
    if row:
        stars = row[0]
        days = {price_1: days_1, price_3: days_3}.get(stars, 30)
        cursor.execute("UPDATE payments SET status = 'completed' WHERE telegram_payload = ?", (payload,))
        conn.commit()
    
    add_premium(message.from_user.id, days)
    await message.answer(f"✅ Premium на {days} дней активирован! 🎉", reply_markup=main_menu())

@router.callback_query(lambda c: c.data == "back_to_menu")
async def back_to_menu_callback(callback: types.CallbackQuery):
    await callback.message.edit_text(
        "🚀 **Флагман Решебник**\n\n"
        "✅ 10 задач в день бесплатно\n"
        "💎 Premium: безлимит\n"
        "👥 Приведи друга → +5 задач\n\n"
        "Выбери режим:",
        reply_markup=main_menu()
    )
    await callback.answer()
