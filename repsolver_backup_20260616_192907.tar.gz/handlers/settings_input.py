from aiogram import Router, types
from aiogram.filters import Filter
from database.db import is_admin, set_setting, get_setting
import logging

logger = logging.getLogger(__name__)
router = Router()

# Импортируем словарь из admin.py
from handlers.admin import waiting_for_input

class WaitingForInputFilter(Filter):
    """Фильтр, который проверяет, ждет ли пользователь ввод"""
    async def __call__(self, message: types.Message) -> bool:
        user_id = message.from_user.id
        return user_id in waiting_for_input

@router.message(WaitingForInputFilter())
async def handle_settings_input(message: types.Message):
    user_id = message.from_user.id
    
    # Если это команда - очищаем ожидание и пропускаем
    if message.text and message.text.startswith('/'):
        if user_id in waiting_for_input:
            del waiting_for_input[user_id]
        return
    
    setting_key = waiting_for_input.get(user_id)
    if not setting_key:
        return
        
    logger.info(f"Processing input from {user_id}, setting: {setting_key}, value: {message.text}")
    
    try:
        value = message.text.strip()
        
        # Проверяем, что введено число (для admin_code пропускаем)
        if setting_key != 'admin_code':
            int(value)
        
        # Сохраняем настройку
        set_setting(setting_key, value)
        
        # Удаляем флаг ожидания
        if user_id in waiting_for_input:
            del waiting_for_input[user_id]
        
        # Отправляем подтверждение
        await message.answer(f"✅ **Настройка изменена!**\n\n"
                            f"📌 `{setting_key}` → `{value}`\n\n"
                            f"Изменения применены!")
        
        # Показываем обновленные настройки
        from handlers.admin import show_settings_callback
        # Создаем фейковый callback
        class FakeCallback:
            def __init__(self, message):
                self.message = message
                self.from_user = message.from_user
            async def answer(self):
                pass
        
        fake_callback = FakeCallback(message)
        await show_settings_callback(fake_callback)
        
    except ValueError:
        await message.answer("❌ Ошибка! Введите число (только цифры).")
    except Exception as e:
        logger.error(f"Error processing input: {e}")
        await message.answer(f"❌ Ошибка: {e}")
