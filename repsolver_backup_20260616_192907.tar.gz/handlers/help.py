from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from keyboards import main_menu

router = Router()

def help_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
    ])

@router.message(Command("help"))
async def help_cmd(message: types.Message):
    text = "❓ **Команды:**\n\n"
    text += "/start — Запустить бота\n"
    text += "/stats — Статистика\n"
    text += "/profile — Профиль\n"
    text += "/settings — Настройки\n"
    text += "/subscribe — Premium\n"
    text += "/referral — Рефералы\n"
    
    await message.answer(text, reply_markup=help_keyboard())

@router.callback_query(lambda c: c.data == "help")
async def help_callback(callback: types.CallbackQuery):
    text = "❓ **Команды:**\n\n"
    text += "/start — Запустить бота\n"
    text += "/stats — Статистика\n"
    text += "/profile — Профиль\n"
    text += "/settings — Настройки\n"
    text += "/subscribe — Premium\n"
    text += "/referral — Рефералы\n"
    
    await callback.message.answer(text, reply_markup=help_keyboard())
    await callback.answer()

@router.callback_query(lambda c: c.data == "back_to_menu")
async def back_to_menu_callback(callback: types.CallbackQuery):
    await callback.message.edit_text(
        "🚀 **Флагман Решебник**\n\n"
        "✅ 10 задач в день бесплатно\n"
        "💎 Premium: безлимит\n"
        "👥 Приведи друга → +5 задач\n\n"
        "Выбери режим:",
        reply_markup=main_menu()
    )
    await callback.answer()
