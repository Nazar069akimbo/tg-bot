from aiogram import Router, types
from aiogram.filters import Command
from database.db import create_user, get_user, get_setting
from keyboards import main_menu

router = Router()

@router.message(Command("start"))
async def start_cmd(message: types.Message):
    user_id = message.from_user.id
    if not get_user(user_id):
        create_user(user_id, message.from_user.username or "")
    
    # Получаем лимит из настроек
    free_limit = int(get_setting('free_limit'))
    
    await message.answer(
        f"🚀 **Флагман Решебник**\n\n"
        f"✅ {free_limit} задач в день бесплатно\n"
        f"💎 Premium: безлимит\n"
        f"👥 Приведи друга → +{get_setting('referral_bonus')} задач\n\n"
        "Выбери режим:",
        reply_markup=main_menu()
    )
