import asyncio
import logging
from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from database.db import is_admin, add_admin, cursor, conn, block_user, unblock_user, get_active_users, get_blocked_users, get_setting, set_setting
from keyboards import main_menu

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = Router()

# Словарь для хранения состояния ожидания ввода - ЭКСПОРТИРУЕМ
waiting_for_input = {}

last_messages = {}

def admin_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
        [InlineKeyboardButton(text="👥 Пользователи", callback_data="admin_users")],
        [InlineKeyboardButton(text="🏆 Топ-10", callback_data="admin_top")],
        [InlineKeyboardButton(text="❌ Блокировка", callback_data="admin_block")],
        [InlineKeyboardButton(text="🔓 Разблокировка", callback_data="admin_unblock")],
        [InlineKeyboardButton(text="⚙️ Настройки", callback_data="admin_settings")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_menu")]
    ])

def settings_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📝 Лимит задач (бесплатно)", callback_data="set_free_limit")],
        [InlineKeyboardButton(text="📝 Лимит задач (Premium)", callback_data="set_premium_limit")],
        [InlineKeyboardButton(text="📏 Символов (бесплатно)", callback_data="set_free_symbols")],
        [InlineKeyboardButton(text="📏 Символов (Premium)", callback_data="set_premium_symbols")],
        [InlineKeyboardButton(text="💰 Цена Premium (1 мес)", callback_data="set_price_1")],
        [InlineKeyboardButton(text="💰 Цена Premium (3 мес)", callback_data="set_price_3")],
        [InlineKeyboardButton(text="🎁 Бонус за реферала", callback_data="set_referral_bonus")],
        [InlineKeyboardButton(text="🔑 Код администратора", callback_data="set_admin_code")],
        [InlineKeyboardButton(text="📊 Текущие настройки", callback_data="show_settings")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="admin_panel")]
    ])

def user_list_keyboard(users, action="block"):
    keyboard = []
    for user in users[:10]:
        user_id = user[0]
        username = user[1] or str(user_id)
        keyboard.append([InlineKeyboardButton(
            text=f"👤 {username}",
            callback_data=f"{action}_{user_id}"
        )])
    keyboard.append([InlineKeyboardButton(text="🔙 Назад", callback_data="admin_panel")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

async def safe_edit_text(message, text, reply_markup=None):
    try:
        msg_id = message.message_id
        if msg_id in last_messages and last_messages[msg_id] == text:
            return
        last_messages[msg_id] = text
        await message.edit_text(text, reply_markup=reply_markup)
    except Exception as e:
        if "message is not modified" not in str(e):
            logger.error(f"Error editing message: {e}")

@router.message(Command("admin"))
async def admin_cmd(message: types.Message):
    user_id = message.from_user.id
    
    if is_admin(user_id):
        await show_admin_panel(message)
    else:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔐 Войти как админ", callback_data="admin_login")]
        ])
        await message.answer(
            "🔐 Требуется авторизация администратора\n\n"
            "Введите код: /admin_code 30121979",
            reply_markup=keyboard
        )

@router.callback_query(lambda c: c.data == "admin_login")
async def admin_login_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "🔐 Введите код: /admin_code 30121979"
    )
    await callback.answer()

@router.message(Command("admin_code"))
async def admin_code_cmd(message: types.Message):
    parts = message.text.split()
    if len(parts) < 2:
        await message.answer("❌ Использование: /admin_code <код>")
        return
    
    admin_code = get_setting('admin_code')
    if parts[1] == admin_code:
        add_admin(message.from_user.id)
        await message.answer("✅ Вы стали администратором! Напишите /admin")
        await show_admin_panel(message)
    else:
        await message.answer("❌ Неверный код!")

@router.callback_query(lambda c: c.data == "admin_panel")
async def admin_panel_callback(callback: CallbackQuery):
    user_id = callback.from_user.id
    
    if is_admin(user_id):
        await show_admin_panel(callback.message)
        await callback.answer()
    else:
        await callback.message.edit_text("🔐 Введите /admin_code 30121979")
        await callback.answer()

async def show_admin_panel(message: types.Message):
    text = "🛡️ **АДМИН-ПАНЕЛЬ**\n\n"
    text += "Выберите действие:"
    
    if isinstance(message, types.Message):
        await message.answer(text, reply_markup=admin_keyboard())
    else:
        await safe_edit_text(message, text, admin_keyboard())

# СТАТИСТИКА
@router.callback_query(lambda c: c.data == "admin_stats")
async def admin_stats_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    cursor.execute("SELECT COUNT(*) FROM users")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM users WHERE premium_until > datetime('now')")
    premium = cursor.fetchone()[0]
    cursor.execute("SELECT SUM(total_requests) FROM users")
    requests = cursor.fetchone()[0] or 0
    cursor.execute("SELECT COUNT(*) FROM users WHERE is_blocked = 1")
    blocked = cursor.fetchone()[0]
    
    text = f"📊 **СТАТИСТИКА**\n\n"
    text += f"👥 Всего: {total}\n"
    text += f"💎 Premium: {premium}\n"
    text += f"🚫 Заблокировано: {blocked}\n"
    text += f"📝 Запросов: {requests}"
    
    await safe_edit_text(callback.message, text, admin_keyboard())
    await callback.answer()

# ПОЛЬЗОВАТЕЛИ
@router.callback_query(lambda c: c.data == "admin_users")
async def admin_users_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    cursor.execute("SELECT user_id, username, total_requests FROM users ORDER BY total_requests DESC LIMIT 30")
    users = cursor.fetchall()
    
    if not users:
        text = "👥 Пока нет пользователей"
        await safe_edit_text(callback.message, text, admin_keyboard())
        await callback.answer()
        return
    
    text = "👥 **ПОЛЬЗОВАТЕЛИ**\n\n"
    for u in users:
        text += f"`{u[0]}` — {u[1] or 'без имени'} — {u[2]} задач\n"
    
    await safe_edit_text(callback.message, text[:4000], admin_keyboard())
    await callback.answer()

# ТОП-10
@router.callback_query(lambda c: c.data == "admin_top")
async def admin_top_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    cursor.execute("SELECT user_id, username, total_requests FROM users ORDER BY total_requests DESC LIMIT 10")
    users = cursor.fetchall()
    
    if not users:
        await safe_edit_text(callback.message, "🏆 Нет данных", admin_keyboard())
        await callback.answer()
        return
    
    text = "🏆 **ТОП-10**\n\n"
    medals = ["🥇", "🥈", "🥉"]
    
    for i, u in enumerate(users, 1):
        medal = medals[i-1] if i <= 3 else f"{i}."
        text += f"{medal} `{u[0]}` — {u[1] or 'без имени'} — {u[2]} задач\n"
    
    await safe_edit_text(callback.message, text, admin_keyboard())
    await callback.answer()

# БЛОКИРОВКА
@router.callback_query(lambda c: c.data == "admin_block")
async def admin_block_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    admin_id = callback.from_user.id
    users = get_active_users()
    users = [u for u in users if u[0] != admin_id]
    
    if not users:
        await safe_edit_text(
            callback.message, 
            "👥 Нет активных пользователей для блокировки",
            admin_keyboard()
        )
        await callback.answer()
        return
    
    text = "❌ **Выберите пользователя для блокировки:**\n\n"
    text += f"Всего активных: {len(users)}\n"
    text += "⚠️ Администратор не может заблокировать себя"
    
    await safe_edit_text(callback.message, text, user_list_keyboard(users, "block_user"))
    await callback.answer()

# РАЗБЛОКИРОВКА
@router.callback_query(lambda c: c.data == "admin_unblock")
async def admin_unblock_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    users = get_blocked_users()
    
    if not users:
        await safe_edit_text(
            callback.message, 
            "👥 Нет заблокированных пользователей",
            admin_keyboard()
        )
        await callback.answer()
        return
    
    text = "🔓 **Выберите пользователя для разблокировки:**\n\n"
    text += f"Заблокировано: {len(users)}"
    
    await safe_edit_text(callback.message, text, user_list_keyboard(users, "unblock_user"))
    await callback.answer()

# ОБРАБОТЧИКИ БЛОКИРОВКИ/РАЗБЛОКИРОВКИ
@router.callback_query(lambda c: c.data.startswith("block_user_"))
async def block_user_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    admin_id = callback.from_user.id
    user_id = int(callback.data.replace("block_user_", ""))
    
    if user_id == admin_id:
        await callback.answer("❌ Вы не можете заблокировать себя!", show_alert=True)
        return
    
    if is_admin(user_id):
        await callback.answer("❌ Вы не можете заблокировать другого администратора!", show_alert=True)
        return
    
    block_user(user_id)
    await callback.answer(f"✅ Пользователь {user_id} заблокирован", show_alert=True)
    await admin_block_callback(callback)

@router.callback_query(lambda c: c.data.startswith("unblock_user_"))
async def unblock_user_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    user_id = int(callback.data.replace("unblock_user_", ""))
    unblock_user(user_id)
    await callback.answer(f"✅ Пользователь {user_id} разблокирован", show_alert=True)
    await admin_unblock_callback(callback)

# ===== НАСТРОЙКИ =====
@router.callback_query(lambda c: c.data == "admin_settings")
async def admin_settings_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    text = "⚙️ **НАСТРОЙКИ БОТА**\n\n"
    text += "Выберите параметр для изменения:"
    
    await safe_edit_text(callback.message, text, settings_keyboard())
    await callback.answer()

# ПОКАЗАТЬ ТЕКУЩИЕ НАСТРОЙКИ
@router.callback_query(lambda c: c.data == "show_settings")
async def show_settings_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    text = "📊 **ТЕКУЩИЕ НАСТРОЙКИ**\n\n"
    text += f"📝 Лимит задач (бесплатно): {get_setting('free_limit')}\n"
    text += f"📝 Лимит задач (Premium): {get_setting('premium_limit')}\n"
    text += f"📏 Символов (бесплатно): {get_setting('free_symbols')}\n"
    text += f"📏 Символов (Premium): {get_setting('premium_symbols')}\n"
    text += f"💰 Premium 1 мес: {get_setting('premium_price_1')} Stars\n"
    text += f"💰 Premium 3 мес: {get_setting('premium_price_3')} Stars\n"
    text += f"🎁 Бонус за реферала: +{get_setting('referral_bonus')} задач\n"
    text += f"🔑 Код администратора: {get_setting('admin_code')}"
    
    await safe_edit_text(callback.message, text, settings_keyboard())
    await callback.answer()

# ФУНКЦИИ ДЛЯ ИЗМЕНЕНИЯ НАСТРОЕК
async def ask_for_value(callback, setting_key, title, current_value):
    """Запрашивает новое значение у администратора"""
    user_id = callback.from_user.id
    waiting_for_input[user_id] = setting_key
    logger.info(f"Waiting for input from {user_id}, setting: {setting_key}")
    
    text = f"⚙️ **{title}**\n\n"
    text += f"Текущее значение: `{current_value}`\n\n"
    text += "Введите новое значение (цифрами):"
    
    await safe_edit_text(callback.message, text, InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Отмена", callback_data="admin_settings")]
    ]))
    await callback.answer()

@router.callback_query(lambda c: c.data == "set_free_limit")
async def set_free_limit_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'free_limit', 'Лимит задач (бесплатно)', get_setting('free_limit'))

@router.callback_query(lambda c: c.data == "set_premium_limit")
async def set_premium_limit_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'premium_limit', 'Лимит задач (Premium)', get_setting('premium_limit'))

@router.callback_query(lambda c: c.data == "set_free_symbols")
async def set_free_symbols_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'free_symbols', 'Максимум символов (бесплатно)', get_setting('free_symbols'))

@router.callback_query(lambda c: c.data == "set_premium_symbols")
async def set_premium_symbols_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'premium_symbols', 'Максимум символов (Premium)', get_setting('premium_symbols'))

@router.callback_query(lambda c: c.data == "set_price_1")
async def set_price_1_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'premium_price_1', 'Цена Premium (1 мес) в Stars', get_setting('premium_price_1'))

@router.callback_query(lambda c: c.data == "set_price_3")
async def set_price_3_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'premium_price_3', 'Цена Premium (3 мес) в Stars', get_setting('premium_price_3'))

@router.callback_query(lambda c: c.data == "set_referral_bonus")
async def set_referral_bonus_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    await ask_for_value(callback, 'referral_bonus', 'Бонус за реферала (задач)', get_setting('referral_bonus'))

@router.callback_query(lambda c: c.data == "set_admin_code")
async def set_admin_code_callback(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа", show_alert=True)
        return
    
    user_id = callback.from_user.id
    waiting_for_input[user_id] = 'admin_code'
    logger.info(f"Waiting for input from {user_id}, setting: admin_code")
    
    text = "🔑 **ИЗМЕНЕНИЕ КОДА АДМИНИСТРАТОРА**\n\n"
    text += f"Текущий код: `{get_setting('admin_code')}`\n\n"
    text += "Введите новый код (только цифры):"
    
    await safe_edit_text(callback.message, text, InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Отмена", callback_data="admin_settings")]
    ]))
    await callback.answer()

@router.callback_query(lambda c: c.data == "back_to_menu")
async def back_to_menu_callback(callback: CallbackQuery):
    # Очищаем состояние ожидания
    user_id = callback.from_user.id
    if user_id in waiting_for_input:
        del waiting_for_input[user_id]
    
    text = "🚀 **Флагман Решебник**\n\n"
    text += "✅ 10 задач в день бесплатно\n"
    text += "💎 Premium: безлимит\n"
    text += "👥 Приведи друга → +5 задач\n\n"
    text += "Выбери режим:"
    
    await safe_edit_text(callback.message, text, main_menu())
    await callback.answer()
