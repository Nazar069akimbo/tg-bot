from . import start
from . import stats
from . import profile
from . import settings
from . import subscribe
from . import referral
from . import solve
from . import admin
from . import leaderboard
from . import help
from .settings_input import router as settings_input_router
