from aiogram import Router, types
from database.db import get_user, can_request, add_request, get_mode, is_premium, get_setting
from ai import solve_problem
from handlers.admin import waiting_for_input

router = Router()

@router.message()
async def solve_message(message: types.Message):
    if not message.text or message.text.startswith("/"):
        return
    
    # Если админ вводит настройку - игнорируем
    if message.from_user.id in waiting_for_input:
        return
    
    user = get_user(message.from_user.id)
    if not user:
        await message.answer("Напиши /start")
        return
    
    ok, remaining = can_request(message.from_user.id)
    if not ok:
        await message.answer(f"🔒 Лимит исчерпан. Купи Premium: /subscribe")
        return
    
    if is_premium(message.from_user.id):
        max_len = int(get_setting('premium_symbols'))
    else:
        max_len = int(get_setting('free_symbols'))
    
    if len(message.text) > max_len:
        await message.answer(f"⚠️ Превышен лимит: {len(message.text)}/{max_len} символов")
        return
    
    status = await message.answer("🔄 Думаю...")
    mode = get_mode(message.from_user.id)
    answer = solve_problem(message.text, mode)
    add_request(message.from_user.id)
    
    emoji = "💬" if mode == "chat" else "📚"
    await status.edit_text(f"{emoji}\n\n{answer}")
