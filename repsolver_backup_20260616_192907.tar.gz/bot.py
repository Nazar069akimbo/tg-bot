import os
import asyncio
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher
from aiogram.types import BotCommand
from aiogram.fsm.storage.memory import MemoryStorage
from database.db import init_db, is_admin, add_admin
from handlers import start, stats, profile, settings, subscribe, referral, solve, admin, leaderboard, help
from handlers.settings_input import router as settings_input_router
from middleware import AuthMiddleware

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", 6957852385))

bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

async def set_commands():
    commands = [
        BotCommand(command="start", description="🚀 Запустить бота"),
        BotCommand(command="stats", description="📊 Статистика"),
        BotCommand(command="profile", description="👤 Профиль"),
        BotCommand(command="settings", description="⚙️ Настройки"),
        BotCommand(command="subscribe", description="💎 Premium"),
        BotCommand(command="referral", description="👥 Рефералы"),
        BotCommand(command="admin", description="🛡️ Админ-панель"),
        BotCommand(command="help", description="❓ Помощь"),
    ]
    await bot.set_my_commands(commands)

async def main():
    init_db()
    if not is_admin(ADMIN_ID):
        add_admin(ADMIN_ID)
    
    await set_commands()
    dp.message.middleware(AuthMiddleware())
    
    # ВАЖНО: сначала подключаем settings_input_router
    dp.include_router(settings_input_router)
    # Затем все остальные
    dp.include_router(start.router)
    dp.include_router(stats.router)
    dp.include_router(profile.router)
    dp.include_router(settings.router)
    dp.include_router(subscribe.router)
    dp.include_router(referral.router)
    dp.include_router(solve.router)
    dp.include_router(admin.router)
    dp.include_router(leaderboard.router)
    dp.include_router(help.router)
    
    print("✅ Бот запущен!")
    print("✅ Все модули загружены!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
